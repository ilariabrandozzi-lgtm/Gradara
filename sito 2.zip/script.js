// Contenuti testuali della guida turistica di Gradara
const siteContent = {
  meta: {
    title: "Gradara — Guida per la prima visita al borgo e alla Rocca",
    description: "Scopri Gradara: storia, la Rocca malatestiana, cosa vedere nel borgo, Paolo e Francesca, sapori locali, eventi e informazioni pratiche per la prima visita."
  },
  nav: [
    { id: "introduzione", label: "Il Borgo" },
    { id: "storia", label: "Storia" },
    { id: "fortezza", label: "La Fortezza" },
    { id: "cosa-vedere", label: "Cosa vedere" },
    { id: "paolo-francesca", label: "Paolo e Francesca" },
    { id: "sapori", label: "Sapori" },
    { id: "eventi", label: "Eventi" },
    { id: "faq", label: "Domande frequenti" }
  ],
  hero: {
    badge: "Marche · Provincia di Pesaro e Urbino",
    title: "Benvenuti a Gradara",
    subtitle: "Un suggestivo borgo medievale racchiuso da una doppia cinta muraria, sospeso tra le colline dell'entroterra e il mare Adriatico.",
    ctaPrimary: { text: "Esplora il borgo", href: "#introduzione" },
    ctaSecondary: { text: "Orari e biglietti ufficiali", href: "https://www.gradara.org/gradara/" },
    heroImage: {
      src: "gradara-panorama-mare.jpg",
      alt: "Veduta panoramica della Rocca di Gradara, della doppia cinta muraria, delle colline e del mare Adriatico sullo sfondo",
      caption: "La Rocca malatestiana e il borgo fortificato dominano il paesaggio tra le colline e il mare Adriatico."
    }
  },
  introduzione: {
    eyebrow: "Alla scoperta del borgo",
    title: "Un balcone medievale tra collina e Adriatico",
    paragraphs: [
      "<strong>Gradara</strong> è un suggestivo borgo medievale delle <strong>Marche</strong>, situato in provincia di Pesaro e Urbino su una collina a 142 metri sul livello del mare. Si trova a circa sei chilometri dalla costa adriatica, nell'immediato entroterra della riviera marchigiano-romagnola e al confine con l'Emilia-Romagna.",
      "L'antico abitato, racchiuso da una doppia cinta muraria e dominato dalla celebre <strong>Rocca malatestiana</strong>, fa parte dei <strong>Borghi più belli d'Italia</strong> ed è insignito della <strong>Bandiera Arancione</strong> del Touring Club Italiano.",
      "Per la sua posizione di confine, offre un ampio panorama che spazia dal mare Adriatico alle colline dell'entroterra (pur appartenendo amministrativamente alle Marche, alcuni autori romagnoli la riconducono alla Romagna storica)."
    ],
    highlights: [
      { value: "142 m", label: "Altitudine sul livello del mare" },
      { value: "~6 km", label: "Distanza dalla costa adriatica" },
      { value: "2", label: "Cinte murarie attorno all'abitato" }
    ],
    recognitions: [
      "Borghi più belli d'Italia",
      "Bandiera Arancione del Touring Club Italiano",
      "Associazione nazionale Città dell'Olio"
    ]
  },
  storia: {
    eyebrow: "Linea del tempo",
    title: "La Storia di Gradara",
    intro: "Dalla prima torre medievale alle contese tra grandi casate rinascimentali, fino al restauro novecentesco che ha restituito la fortezza al suo splendore.",
    timeline: [
      {
        period: "Intorno al 1150",
        title: "Le origini e il mastio dei De Grifo",
        text: "La potente famiglia dei <strong>De Grifo</strong> (o <strong>De Griffo</strong>) costruì il mastio originario sulla sommità del colle di Gradara."
      },
      {
        period: "XIII–XIV secolo",
        title: "La signoria dei Malatesta e le cinte murarie",
        text: "Caduti in disgrazia i De Grifo presso il papato, la signoria passò ai <strong>Malatesta</strong>, che trasformarono il mastio in rocca ed edificarono le due cinte murarie. <em>Nota storica:</em> una fonte colloca l'avvio dell'epopea malatestiana e la prima fortificazione intorno al 1200, mentre altre datano la costruzione della fortezza e delle due cinte di mura tra il XIII e il XIV secolo (con ampliamenti fino al XV secolo)."
      },
      {
        period: "1446",
        title: "L'assedio dei 40 giorni",
        text: "Dopo la vendita di Gradara a Francesco Sforza nel 1445 e il rifiuto di Sigismondo Pandolfo Malatesta di consegnarla, lo Sforza e Federico da Montefeltro assediarono la fortezza per 40 giorni con cannoni e bombarde. Le intemperie e l'arrivo dei rinforzi malatestiani costrinsero tuttavia gli assedianti alla ritirata."
      },
      {
        period: "1463",
        title: "La resa e il vicariato degli Sforza di Pesaro",
        text: "Scomunicato da papa Pio II, Sigismondo Pandolfo Malatesta dovette affrontare un nuovo assedio guidato da Federico da Montefeltro per conto della Chiesa, che portò alla resa della fortezza. Il Papa la affidò quindi in vicariato agli <strong>Sforza di Pesaro</strong>, sotto i quali Giovanni Sforza la trasformò in un sicuro luogo di soggiorno e rappresentanza."
      },
      {
        period: "1641",
        title: "Il passaggio allo Stato della Chiesa",
        text: "Dopo essersi contesa tra importanti casate — tra cui <strong>Borgia</strong>, <strong>Della Rovere</strong> e <strong>Medici</strong> — Gradara passò sotto il diretto controllo dello <strong>Stato della Chiesa</strong> tramite i legati pontifici."
      },
      {
        period: "1920–1928",
        title: "Il restauro di Umberto Zanvettori",
        text: "L'ingegnere <strong>Umberto Zanvettori</strong> acquistò nel 1920 la rocca ridotta a rudere e ne finanziò il restauro insieme alla cinta muraria, riportando il complesso all'antico splendore. Nel 1928 il castello fu venduto allo <strong>Stato italiano</strong> (con diritto di usufrutto per la vedova Alberta Porta Natale fino al 1983)."
      }
    ]
  },
  fortezza: {
    eyebrow: "Il cuore monumentale",
    title: "La Fortezza",
    description: [
      "Costruita attorno al 1150 a partire dal mastio dei De Grifo, ampliata dai Malatesta con due cinte murarie, trasformata in residenza signorile dagli Sforza e restaurata negli anni Venti del Novecento da Umberto Zanvettori, la <strong>Rocca di Gradara</strong> è oggi un monumento statale gestito dal Ministero della Cultura tramite la Direzione regionale Musei, oltre a essere sede di eventi museali, musicali e artistici.",
      "La struttura sorge a 142 metri sul livello del mare, con un <strong>mastio alto 30 metri</strong> e una <strong>cinta muraria esterna lunga quasi 800 metri</strong>, dotata di tre ponti levatoi e diciassette torrioni merlati.",
      "Oggi i visitatori possono esplorare le sale interne riccamente arredate — tra cui la stanza legata alla leggenda di <strong>Paolo e Francesca</strong>, le esposizioni di abiti e armature medievali, armi, strumenti di tortura e la cappella al piano terra con il curioso «orecchio di Dioniso» — oltre a percorrere un tratto dei camminamenti di ronda lungo le merlature."
    ],
    image: {
      src: "rocca-di-gradara.jpg",
      alt: "La Rocca di Gradara con le merlature guelfe, il mastio e i tetti del borgo antico",
      caption: "La Rocca di Gradara con il mastio alto 30 metri e le caratteristiche merlature."
    },
    specs: [
      { label: "Epoca di costruzione", value: "Attorno al 1150 (mastio originario) con ampliamenti tra XIII e XIV secolo (fino al XV secolo secondo una fonte; avvio malatestiano intorno al 1200 secondo un'altra)." },
      { label: "Protagonisti", value: "Famiglia De Grifo/De Griffo (mastio), Malatesta (fortezza e due cinte murarie), Giovanni Sforza (trasformazioni rinascimentali) e Umberto Zanvettori (restauro del 1920)." },
      { label: "Dimensioni e difese", value: "Mastio alto 30 metri e cinta muraria esterna di quasi 800 metri su un colle a 142 m s.l.m., con 3 ponti levatoi e 17 torrioni merlati." },
      { label: "Assedi principali", value: "1446 (assedio di 40 giorni di Francesco Sforza e Federico da Montefeltro, fallito) e 1463 (assedio di Federico da Montefeltro per papa Pio II, concluso con la resa)." },
      { label: "Uso attuale", value: "Monumento statale visitabile gestito dal Ministero della Cultura tramite la Direzione regionale Musei; sede di eventi museali, musicali e artistici." },
      { label: "Percorso di visita", value: "Sale interne arredate, stanza di Paolo e Francesca, abiti, armature, armi, strumenti di tortura, cappella con l'«orecchio di Dioniso» e camminamenti di ronda." }
    ]
  },
  cosaVedere: {
    eyebrow: "Itinerario nel centro storico",
    title: "Cosa vedere nel borgo",
    intro: "Oltre alla Rocca, passeggiare lungo le vie acciottolate di Gradara permette di scoprire scorci panoramici, musei e architetture storiche.",
    image: {
      src: "borgo-torre-orologio.jpg",
      alt: "Scorcio della via principale del borgo di Gradara con vista sulla Torre dell'Orologio",
      caption: "La via centrale del borgo storico con sullo sfondo la Torre dell'Orologio."
    },
    places: [
      {
        title: "Camminamenti di Ronda",
        tag: "Panorama",
        description: "Offrono un percorso di circa 300 metri lungo le antiche merlature fino all'ingresso del castello, regalando un panorama sul territorio circostante e, nelle giornate limpide, sul mare."
      },
      {
        title: "Museo Storico e Grotte medievali",
        tag: "Storia e sottosuolo",
        description: "Situato in piazza V Novembre, il museo espone reperti sulla vita del borgo, armi, strumenti di tortura e testimonianze della civiltà contadina, consentendo inoltre di visitare una parte delle grotte tufacee medievali risalenti al IV-V secolo d.C."
      },
      {
        title: "Palazzo Rubini Vesin",
        tag: "Cultura",
        description: "Ospita mostre temporanee all'interno di un centro espositivo nel cuore del borgo."
      },
      {
        title: "Chiesa parrocchiale di San Giovanni Battista",
        tag: "Architettura sacra",
        description: "È uno dei principali luoghi d'interesse storico e religioso presenti all'interno dell'abitato."
      },
      {
        title: "Torre dell'Orologio",
        tag: "Simbolo del borgo",
        description: "Costituisce uno dei monumenti caratteristici che impreziosiscono il centro storico di Gradara."
      }
    ]
  },
  paoloFrancesca: {
    eyebrow: "Letteratura e leggenda",
    title: "La storia di Paolo e Francesca",
    subtitle: "Il celebre amore cantato da Dante Alighieri tra le mura della Rocca",
    paragraphs: [
      "Il Castello di Gradara è una delle strutture medievali meglio conservate d'Italia ed è indissolubilmente legato alla celebre vicenda di <strong>Paolo e Francesca</strong>, resa immortale da <strong>Dante Alighieri</strong> nell'<em>Inferno</em> della <em>Divina Commedia</em>.",
      "Secondo la leggenda, proprio all'interno della rocca si consumò l'amore tra <strong>Francesca da Polenta</strong> e <strong>Paolo Malatesta</strong>, scoperto e punito con la morte dal marito di lei, <strong>Gianciotto Malatesta</strong> — descritto dalle fonti storiche come sciancato in una testimonianza e come zoppo e orbo in un'altra.",
      "Durante la visita alle sale interne riccamente arredate della Rocca è possibile ammirare la stanza tradizionalmente legata a questa celebre vicenda."
    ],
    quote: "«Secondo la leggenda resa celebre da Dante nell'Inferno, nella rocca si consumò l'amore tra Francesca da Polenta e Paolo Malatesta.»"
  },
  sapori: {
    eyebrow: "Enogastronomia del territorio",
    title: "Sapori di Gradara",
    lead: "Gradara sorge in un territorio ricco di <strong>ulivi e vigneti</strong> e fa parte dell'associazione nazionale <strong>Città dell'Olio</strong>. Nelle trattorie e nei ristoranti del borgo si gusta una cucina <strong>marchigiano-romagnola</strong>, che unisce le tradizioni gastronomiche delle Marche e dell'Emilia-Romagna.",
    cards: [
      {
        title: "Tagliolini con la Bomba",
        badge: "Piatto tipico locale",
        text: "Sono la specialità gastronomica simbolo di Gradara: un piatto della tradizione contadina il cui nome curioso deriva dalla particolare modalità di preparazione."
      },
      {
        title: "Cucina marchigiano-romagnola",
        badge: "Tradizione di confine",
        text: "Le trattorie e i ristoranti del centro storico propongono ricette che fondono i sapori delle Marche e dell'Emilia-Romagna, accompagnati dai prodotti delle colline circostanti."
      },
      {
        title: "Il Medioevo a Tavola",
        badge: "Esperienza gastronomica",
        text: "Durante l'anno, questa iniziativa trasforma i ristoranti del borgo in taverne quattrocentesche con giornate interamente dedicate alla cucina medievale."
      }
    ]
  },
  eventi: {
    eyebrow: "Il borgo si anima",
    title: "Eventi e rievocazioni",
    intro: "Nel corso dell'anno Gradara ospita rievocazioni storiche, festival tematici e appuntamenti stagionali che coinvolgono tutto il centro storico.",
    image: {
      src: "gradara-sera-illuminata.jpg",
      alt: "Veduta serale della Rocca e delle mura di Gradara illuminate al crepuscolo",
      caption: "La cinta muraria e la Rocca illuminate al crepuscolo regalano un'atmosfera suggestiva."
    },
    items: [
      {
        period: "Penultimo weekend di luglio",
        title: "Assedio al Castello",
        featured: true,
        description: "È l'evento principale di Gradara: la rievocazione storica dell'assedio del 1446, aperta da uno spettacolo piromusicale e animata da oltre cento figuranti, cavalli, effetti speciali e giornate medievali nel centro storico."
      },
      {
        period: "Festival tematico",
        title: "The Dragon Castle",
        featured: false,
        description: "Festival celtico dedicato alle fiabe e ai sogni, ambientato nella cornice suggestiva del borgo fortificato."
      },
      {
        period: "Manifestazione storica",
        title: "Gradara Ludens",
        featured: false,
        description: "Storica manifestazione dedicata al gioco, nata negli anni Novanta e ripristinata dal 2023."
      },
      {
        period: "Durante l'anno",
        title: "Appuntamenti stagionali e tematici",
        featured: false,
        description: "Il calendario del borgo comprende le giornate di cucina medievale (<em>Il Medioevo a Tavola</em>), le iniziative autunnali (<em>Halloweekend</em>, <em>Castelli d'aria</em>, <em>Novembre a Gradara</em>) e il <em>Castello di Natale</em>."
      }
    ]
  },
  faq: {
    eyebrow: "Informazioni utili per la prima visita",
    title: "Domande frequenti",
    items: [
      {
        question: "Dove si trova Gradara e quanto dista dal mare?",
        answer: "Gradara si trova nelle Marche, in provincia di Pesaro e Urbino, al confine con l'Emilia-Romagna. Sorge su una collina a circa sei chilometri dalla costa adriatica, nell'entroterra della riviera marchigiano-romagnola."
      },
      {
        question: "Perché il Castello di Gradara è così famoso?",
        answer: "È una delle strutture medievali meglio conservate d'Italia ed è legato alla celebre vicenda di Paolo e Francesca, cantata da Dante Alighieri nella <em>Divina Commedia</em>. Per il suo valore storico e architettonico è tra i musei più visitati delle Marche."
      },
      {
        question: "Si può camminare sulle mura del castello?",
        answer: "Sì, è possibile percorrere una parte dei camminamenti di ronda lungo le merlature per circa 300 metri fino all'ingresso della fortezza. Il percorso regala una vista panoramica sul territorio circostante e, nelle giornate limpide, sul mare."
      },
      {
        question: "Qual è il piatto tipico da assaggiare a Gradara?",
        answer: "La specialità tipica di Gradara sono i <strong>«Tagliolini con la Bomba»</strong>, un piatto della tradizione contadina. Nei locali del borgo è inoltre possibile gustare la cucina marchigiano-romagnola."
      },
      {
        question: "Qual è il periodo più indicato per assistere alle rievocazioni storiche?",
        answer: "L'appuntamento principale è <strong>«Assedio al Castello»</strong>, la rievocazione storica dell'assedio del 1446 che si tiene ogni anno nel penultimo weekend di luglio. Durante l'anno il borgo ospita anche festival, giornate di cucina medievale ed eventi natalizi."
      }
    ],
    officialLink: {
      text: "Consulta orari di apertura e biglietti sul sito ufficiale di Gradara",
      url: "https://www.gradara.org/gradara/"
    }
  },
  footer: {
    title: "Gradara",
    subtitle: "Guida introduttiva alla visita del borgo fortificato e della Rocca malatestiana.",
    linkLabel: "Orari e biglietti: gradara.org/gradara",
    linkUrl: "https://www.gradara.org/gradara/"
  }
};

// Popolamento dinamico dei contenuti nella pagina
document.addEventListener("DOMContentLoaded", () => {
  document.title = siteContent.meta.title;
  const metaDesc = document.querySelector('meta[name="description"]');
  if (metaDesc) metaDesc.setAttribute("content", siteContent.meta.description);

  // Navigazione
  const navList = document.getElementById("nav-list");
  siteContent.nav.forEach((item) => {
    const li = document.createElement("li");
    const a = document.createElement("a");
    a.href = `#${item.id}`;
    a.textContent = item.label;
    li.appendChild(a);
    navList.appendChild(li);
  });

  // Menu mobile toggle
  const menuToggle = document.getElementById("menu-toggle");
  const navMenu = document.getElementById("nav-menu");
  menuToggle.addEventListener("click", () => {
    const isExpanded = menuToggle.getAttribute("aria-expanded") === "true";
    menuToggle.setAttribute("aria-expanded", String(!isExpanded));
    navMenu.classList.toggle("open");
  });

  navList.addEventListener("click", (e) => {
    if (e.target.tagName === "A") {
      navMenu.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
    }
  });

  // Hero
  document.getElementById("hero-badge").textContent = siteContent.hero.badge;
  document.getElementById("hero-title").textContent = siteContent.hero.title;
  document.getElementById("hero-subtitle").textContent = siteContent.hero.subtitle;

  const heroCtaPrimary = document.getElementById("hero-cta-primary");
  heroCtaPrimary.textContent = siteContent.hero.ctaPrimary.text;
  heroCtaPrimary.href = siteContent.hero.ctaPrimary.href;

  const heroCtaSecondary = document.getElementById("hero-cta-secondary");
  heroCtaSecondary.textContent = siteContent.hero.ctaSecondary.text;
  heroCtaSecondary.href = siteContent.hero.ctaSecondary.href;

  const heroImg = document.getElementById("hero-img");
  heroImg.src = siteContent.hero.heroImage.src;
  heroImg.alt = siteContent.hero.heroImage.alt;
  document.getElementById("hero-caption").textContent = siteContent.hero.heroImage.caption;

  // Introduzione
  document.getElementById("intro-eyebrow").textContent = siteContent.introduzione.eyebrow;
  document.getElementById("intro-title").textContent = siteContent.introduzione.title;

  const introParagraphs = document.getElementById("intro-paragraphs");
  siteContent.introduzione.paragraphs.forEach((html) => {
    const p = document.createElement("p");
    p.innerHTML = html;
    introParagraphs.appendChild(p);
  });

  const introHighlights = document.getElementById("intro-highlights");
  siteContent.introduzione.highlights.forEach((stat) => {
    const card = document.createElement("div");
    card.className = "stat-card";
    card.innerHTML = `<span class="stat-value">${stat.value}</span><span class="stat-label">${stat.label}</span>`;
    introHighlights.appendChild(card);
  });

  const recognitionsList = document.getElementById("intro-recognitions");
  siteContent.introduzione.recognitions.forEach((rec) => {
    const span = document.createElement("span");
    span.className = "badge-pill";
    span.textContent = rec;
    recognitionsList.appendChild(span);
  });

  // Storia (Linea del tempo)
  document.getElementById("storia-eyebrow").textContent = siteContent.storia.eyebrow;
  document.getElementById("storia-title").textContent = siteContent.storia.title;
  document.getElementById("storia-intro").textContent = siteContent.storia.intro;

  const timelineContainer = document.getElementById("timeline-container");
  siteContent.storia.timeline.forEach((step) => {
    const item = document.createElement("article");
    item.className = "timeline-item";
    item.innerHTML = `
      <div class="timeline-marker"></div>
      <div class="timeline-content">
        <span class="timeline-period">${step.period}</span>
        <h3>${step.title}</h3>
        <p>${step.text}</p>
      </div>
    `;
    timelineContainer.appendChild(item);
  });

  // La Fortezza
  document.getElementById("fortezza-eyebrow").textContent = siteContent.fortezza.eyebrow;
  document.getElementById("fortezza-title").textContent = siteContent.fortezza.title;

  const fortezzaText = document.getElementById("fortezza-text");
  siteContent.fortezza.description.forEach((html) => {
    const p = document.createElement("p");
    p.innerHTML = html;
    fortezzaText.appendChild(p);
  });

  const fortezzaImg = document.getElementById("fortezza-img");
  fortezzaImg.src = siteContent.fortezza.image.src;
  fortezzaImg.alt = siteContent.fortezza.image.alt;
  document.getElementById("fortezza-caption").textContent = siteContent.fortezza.image.caption;

  const specsGrid = document.getElementById("fortezza-specs");
  siteContent.fortezza.specs.forEach((spec) => {
    const box = document.createElement("div");
    box.className = "spec-card";
    box.innerHTML = `<h4>${spec.label}</h4><p>${spec.value}</p>`;
    specsGrid.appendChild(box);
  });

  // Cosa vedere
  document.getElementById("vedere-eyebrow").textContent = siteContent.cosaVedere.eyebrow;
  document.getElementById("vedere-title").textContent = siteContent.cosaVedere.title;
  document.getElementById("vedere-intro").textContent = siteContent.cosaVedere.intro;

  const vedereImg = document.getElementById("vedere-img");
  vedereImg.src = siteContent.cosaVedere.image.src;
  vedereImg.alt = siteContent.cosaVedere.image.alt;
  document.getElementById("vedere-caption").textContent = siteContent.cosaVedere.image.caption;

  const placesGrid = document.getElementById("places-grid");
  siteContent.cosaVedere.places.forEach((place) => {
    const card = document.createElement("article");
    card.className = "place-card";
    card.innerHTML = `
      <span class="place-tag">${place.tag}</span>
      <h3>${place.title}</h3>
      <p>${place.description}</p>
    `;
    placesGrid.appendChild(card);
  });

  // Paolo e Francesca
  document.getElementById("pf-eyebrow").textContent = siteContent.paoloFrancesca.eyebrow;
  document.getElementById("pf-title").textContent = siteContent.paoloFrancesca.title;
  document.getElementById("pf-subtitle").textContent = siteContent.paoloFrancesca.subtitle;
  document.getElementById("pf-quote").textContent = siteContent.paoloFrancesca.quote;

  const pfText = document.getElementById("pf-text");
  siteContent.paoloFrancesca.paragraphs.forEach((html) => {
    const p = document.createElement("p");
    p.innerHTML = html;
    pfText.appendChild(p);
  });

  // Sapori
  document.getElementById("sapori-eyebrow").textContent = siteContent.sapori.eyebrow;
  document.getElementById("sapori-title").textContent = siteContent.sapori.title;
  document.getElementById("sapori-lead").innerHTML = siteContent.sapori.lead;

  const saporiGrid = document.getElementById("sapori-grid");
  siteContent.sapori.cards.forEach((cardData) => {
    const card = document.createElement("article");
    card.className = "flavor-card";
    card.innerHTML = `
      <span class="flavor-badge">${cardData.badge}</span>
      <h3>${cardData.title}</h3>
      <p>${cardData.text}</p>
    `;
    saporiGrid.appendChild(card);
  });

  // Eventi
  document.getElementById("eventi-eyebrow").textContent = siteContent.eventi.eyebrow;
  document.getElementById("eventi-title").textContent = siteContent.eventi.title;
  document.getElementById("eventi-intro").textContent = siteContent.eventi.intro;

  const eventiImg = document.getElementById("eventi-img");
  eventiImg.src = siteContent.eventi.image.src;
  eventiImg.alt = siteContent.eventi.image.alt;
  document.getElementById("eventi-caption").textContent = siteContent.eventi.image.caption;

  const eventiList = document.getElementById("eventi-list");
  siteContent.eventi.items.forEach((ev) => {
    const card = document.createElement("article");
    card.className = ev.featured ? "event-card featured" : "event-card";
    card.innerHTML = `
      <span class="event-period">${ev.period}</span>
      <h3>${ev.title}</h3>
      <p>${ev.description}</p>
    `;
    eventiList.appendChild(card);
  });

  // FAQ (Accordion)
  document.getElementById("faq-eyebrow").textContent = siteContent.faq.eyebrow;
  document.getElementById("faq-title").textContent = siteContent.faq.title;

  const faqContainer = document.getElementById("faq-container");
  siteContent.faq.items.forEach((faq, idx) => {
    const item = document.createElement("div");
    item.className = "faq-item";
    const btnId = `faq-btn-${idx}`;
    const panelId = `faq-panel-${idx}`;
    item.innerHTML = `
      <button class="faq-question" id="${btnId}" aria-expanded="${idx === 0 ? "true" : "false"}" aria-controls="${panelId}">
        <span>${faq.question}</span>
        <span class="faq-icon" aria-hidden="true">+</span>
      </button>
      <div class="faq-answer ${idx === 0 ? "open" : ""}" id="${panelId}" role="region" aria-labelledby="${btnId}">
        <p>${faq.answer}</p>
      </div>
    `;
    const btn = item.querySelector(".faq-question");
    const panel = item.querySelector(".faq-answer");
    btn.addEventListener("click", () => {
      const expanded = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", String(!expanded));
      panel.classList.toggle("open");
    });
    faqContainer.appendChild(item);
  });

  const officialBtn = document.getElementById("official-tickets-link");
  officialBtn.textContent = siteContent.faq.officialLink.text;
  officialBtn.href = siteContent.faq.officialLink.url;

  // Footer
  document.getElementById("footer-title").textContent = siteContent.footer.title;
  document.getElementById("footer-subtitle").textContent = siteContent.footer.subtitle;
  const footerLink = document.getElementById("footer-official-link");
  footerLink.textContent = siteContent.footer.linkLabel;
  footerLink.href = siteContent.footer.linkUrl;
});
